package com.magiclauncher.ui

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import android.view.HapticFeedbackConstants
import com.magiclauncher.data.IconRepository
import com.magiclauncher.model.AppInfo
import com.magiclauncher.model.LauncherSettings

sealed class DockEntry(val id: String) {
    class Pinned(val app: AppInfo) : DockEntry("p:${app.key}")
    class Recent(val app: AppInfo) : DockEntry("r:${app.key}")
    data object Divider : DockEntry("divider")
}

/**
 * MagicOS-style dock: [pinned | divider | recents]. Width is recomputed from the entry count and spring-animated;
 * entries slide/fade via LazyRow.animateItem when apps are pinned, unpinned or recents change.
 */
@Composable
fun DynamicDock(
    pinned: List<AppInfo>, recents: List<AppInfo>, settings: LauncherSettings,
    holder: WallpaperHolder, rootSize: IntSize, progress: () -> Float,
    icons: IconRepository, iconVersion: Int, bottomInset: Dp,
    onTap: (AppInfo, Rect) -> Unit, onLongPress: (AppInfo) -> Unit,
    menuFor: @Composable (AppInfo) -> Unit,
    modifier: Modifier = Modifier
) {
    val iconDp = 64.dp * settings.iconScale
    val slot = iconDp + 18.dp
    val dividerSlot = 22.dp
    val entries = remember(pinned, recents, settings.dockShowRecents) {
        buildList<DockEntry> {
            pinned.forEach { add(DockEntry.Pinned(it)) }
            if (settings.dockShowRecents && recents.isNotEmpty()) {
                if (pinned.isNotEmpty()) add(DockEntry.Divider)
                recents.forEach { add(DockEntry.Recent(it)) }
            }
        }
    }
    var total = 28.dp
    entries.forEach { total += if (it is DockEntry.Divider) dividerSlot else slot }
    val animW by animateDpAsState(total, Springs.page(), label = "dockWidth")
    val height = iconDp + 30.dp
    val floating = settings.dockFloating
    val shape = if (floating) RoundedCornerShape(38.dp) else RoundedCornerShape(topStart = 34.dp, topEnd = 34.dp)
    var dockPos by remember { mutableStateOf(Offset.Zero) }

    val outer = if (floating) modifier.padding(bottom = bottomInset + 14.dp).width(animW).height(height)
    else modifier.fillMaxWidth().height(height + bottomInset)

    Box(outer) {
        Box(Modifier.fillMaxSize().onGloballyPositioned { dockPos = it.positionInRoot() }) {
            GlassBackdrop(Modifier.fillMaxSize(), shape, holder, rootSize, { dockPos }, progress, settings)
        }
        LazyRow(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, bottom = if (floating) 0.dp else bottomInset),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
            userScrollEnabled = false
        ) {
            items(entries, key = { it.id }) { e ->
                Box(
                    Modifier.animateItem(fadeInSpec = tween(250), placementSpec = Springs.page(), fadeOutSpec = tween(200))
                        .width(if (e is DockEntry.Divider) dividerSlot else slot).height(iconDp + 30.dp),
                    contentAlignment = Alignment.Center
                ) {
                    when (e) {
                        is DockEntry.Divider -> Box(Modifier.width(1.dp).height(iconDp * 0.6f).background(Color.White.copy(alpha = 0.38f)))
                        is DockEntry.Pinned -> DockIcon(e.app, icons, iconVersion, settings, iconDp, onTap, onLongPress, menuFor)
                        is DockEntry.Recent -> DockIcon(e.app, icons, iconVersion, settings, iconDp, onTap, onLongPress, menuFor)
                    }
                }
            }
        }
    }
}

@Composable
private fun DockIcon(
    app: AppInfo, icons: IconRepository, version: Int, settings: LauncherSettings, size: Dp,
    onTap: (AppInfo, Rect) -> Unit, onLongPress: (AppInfo) -> Unit, menuFor: @Composable (AppInfo) -> Unit
) {
    val view = LocalView.current
    var pressed by remember { mutableStateOf(false) }
    val sc by animateFloatAsState(if (pressed) 0.88f else 1f, Springs.pop(), label = "dockPress")
    var bounds by remember { mutableStateOf(Rect.Zero) }
    val tap by rememberUpdatedState(onTap)
    val lp by rememberUpdatedState(onLongPress)
    Box(
        Modifier.graphicsLayer { scaleX = sc; scaleY = sc }
            .onGloballyPositioned { bounds = it.boundsInWindow() }
            .pointerInput(app.key) {
                detectTapGestures(
                    onPress = { pressed = true; tryAwaitRelease(); pressed = false },
                    onTap = { tap(app, bounds) },
                    onLongPress = { view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS); lp(app) }
                )
            }
    ) {
        AppGlyph(app.key, icons, version, settings.iconShape, size)
        menuFor(app)
    }
}
