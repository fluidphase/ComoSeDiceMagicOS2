package com.magiclauncher.data

import android.content.Context
import com.magiclauncher.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SettingsRepository(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("launcher_settings", Context.MODE_PRIVATE)
    private val _flow = MutableStateFlow(load())
    val flow: StateFlow<LauncherSettings> = _flow.asStateFlow()

    fun update(transform: (LauncherSettings) -> LauncherSettings) {
        val n = transform(_flow.value)
        _flow.value = n
        save(n)
    }

    private inline fun <reified E : Enum<E>> enumOf(key: String, def: E): E =
        try { enumValueOf<E>(prefs.getString(key, def.name) ?: def.name) } catch (e: Exception) { def }

    private fun load(): LauncherSettings {
        val d = LauncherSettings()
        return LauncherSettings(
            gridCols = prefs.getInt("gridCols", d.gridCols),
            gridRows = prefs.getInt("gridRows", d.gridRows),
            parallax = prefs.getBoolean("parallax", d.parallax),
            iconShape = enumOf("iconShape", d.iconShape),
            iconScale = prefs.getFloat("iconScale", d.iconScale),
            showLabels = prefs.getBoolean("showLabels", d.showLabels),
            iconPack = prefs.getString("iconPack", null),
            dockBlurEnabled = prefs.getBoolean("dockBlurEnabled", d.dockBlurEnabled),
            dockBlurRadiusDp = prefs.getInt("dockBlurRadiusDp", d.dockBlurRadiusDp),
            dockTintAlpha = prefs.getFloat("dockTintAlpha", d.dockTintAlpha),
            dockShowRecents = prefs.getBoolean("dockShowRecents", d.dockShowRecents),
            dockMaxRecents = prefs.getInt("dockMaxRecents", d.dockMaxRecents),
            dockFloating = prefs.getBoolean("dockFloating", d.dockFloating),
            gestureSwipeDown = prefs.getBoolean("gSwipeDown", d.gestureSwipeDown),
            gestureSwipeUp = prefs.getBoolean("gSwipeUp", d.gestureSwipeUp),
            swipeUpAction = enumOf("swipeUpAction", d.swipeUpAction),
            gesturePinch = prefs.getBoolean("gPinch", d.gesturePinch),
            gestureDoubleTap = prefs.getBoolean("gDoubleTap", d.gestureDoubleTap),
            defaultFolderStyle = enumOf("defaultFolderStyle", d.defaultFolderStyle),
            weatherLat = prefs.getFloat("weatherLat", d.weatherLat.toFloat()).toDouble(),
            weatherLon = prefs.getFloat("weatherLon", d.weatherLon.toFloat()).toDouble()
        )
    }

    private fun save(s: LauncherSettings) {
        prefs.edit()
            .putInt("gridCols", s.gridCols).putInt("gridRows", s.gridRows).putBoolean("parallax", s.parallax)
            .putString("iconShape", s.iconShape.name).putFloat("iconScale", s.iconScale)
            .putBoolean("showLabels", s.showLabels).putString("iconPack", s.iconPack)
            .putBoolean("dockBlurEnabled", s.dockBlurEnabled).putInt("dockBlurRadiusDp", s.dockBlurRadiusDp)
            .putFloat("dockTintAlpha", s.dockTintAlpha).putBoolean("dockShowRecents", s.dockShowRecents)
            .putInt("dockMaxRecents", s.dockMaxRecents).putBoolean("dockFloating", s.dockFloating)
            .putBoolean("gSwipeDown", s.gestureSwipeDown).putBoolean("gSwipeUp", s.gestureSwipeUp)
            .putString("swipeUpAction", s.swipeUpAction.name).putBoolean("gPinch", s.gesturePinch)
            .putBoolean("gDoubleTap", s.gestureDoubleTap).putString("defaultFolderStyle", s.defaultFolderStyle.name)
            .putFloat("weatherLat", s.weatherLat.toFloat()).putFloat("weatherLon", s.weatherLon.toFloat())
            .apply()
    }
}
