package com.magiclauncher.ui

import android.os.Build
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.magiclauncher.data.IconRepository
import com.magiclauncher.model.*
import kotlin.math.min
import android.view.HapticFeedbackConstants

/** Geometry shared by drawing and tap hit-testing, so a folder's icons are launchable directly (no overlay first). */
data class FolderGeom(val cols: Int, val rows: Int, val left: Float, val top: Float, val cell: Float, val iconSize: Float) {
    fun rect(i: Int): Rect {
        val r = i / cols; val c = i % cols
        return Rect(left + c * cell, top + r * cell, left + (c + 1) * cell, top + (r + 1) * cell)
    }
}

fun folderGeom(style: FolderStyle, w: Float, h: Float, d: Float): FolderGeom {
    val cols = when (style) { FolderStyle.BIG -> 3; FolderStyle.WIDE -> 4; FolderStyle.STANDARD -> 2 }
    val rows = when (style) { FolderStyle.BIG -> 3; FolderStyle.WIDE -> 2; FolderStyle.STANDARD -> 2 }
    val titleH = 22f * d
    val pad = 14f * d
    val availW = w - 2 * pad
    val availH = h - 2 * pad - titleH + 8f * d
    val cell = min(availW / cols, availH / rows)
    return FolderGeom(cols, rows, (w - cell * cols) / 2f, pad + (availH - cell * rows) / 2f, cell, cell * 0.78f)
}

/** Returns (icons shown, overflow cell present). BIG shows up to 9 slots, WIDE 8; the last slot becomes "+N". */
fun folderVisible(style: FolderStyle, count: Int): Pair<Int, Boolean> {
    val cap = when (style) { FolderStyle.BIG -> 9; FolderStyle.WIDE -> 8; FolderStyle.STANDARD -> 4 }
    return if (style == FolderStyle.STANDARD) min(count, 4) to false
    else if (count <= cap) count to false else (cap - 1) to true
}

sealed interface FolderHit {
    data class Child(val index: Int) : FolderHit
    data object Overflow : FolderHit
    data object Open : FolderHit
}

fun folderHit(item: HomeItem, w: Float, h: Float, density: Float, p: Offset): FolderHit {
    if (item.folderStyle == FolderStyle.STANDARD) return FolderHit.Open
    val g = folderGeom(item.folderStyle, w, h, density)
    val (shown, overflow) = folderVisible(item.folderStyle, item.children.size)
    val total = shown + if (overflow) 1 else 0
    for (i in 0 until total) if (g.rect(i).contains(p)) return if (i < shown) FolderHit.Child(i) else FolderHit.Overflow
    return FolderHit.Open
}

@Composable
fun FolderCell(
    item: HomeItem, appMap: Map<String, AppInfo>, icons: IconRepository, version: Int,
    settings: LauncherSettings, w: Float, h: Float, modifier: Modifier = Modifier
) {
    val d = LocalDensity.current
    val dens = d.density
    val label = item.title.ifEmpty { "Folder" }
    if (item.folderStyle == FolderStyle.STANDARD) {
        val tile = with(d) { min(min(w, h) * 0.58f, 76f * dens) * settings.iconScale }
        val tileDp = with(d) { tile.toDp() }
        Column(modifier, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Box(Modifier.size(tileDp).clip(settings.iconShape.toShape()).background(Color.White.copy(alpha = 0.22f)).padding(tileDp * 0.1f)) {
                val mini = tileDp * 0.4f
                item.children.take(4).forEachIndexed { i, k ->
                    Box(Modifier.offset(x = mini * 1.05f * (i % 2), y = mini * 1.05f * (i / 2))) {
                        AppGlyph(k, icons, version, settings.iconShape, mini)
                    }
                }
            }
            if (settings.showLabels) { Spacer(Modifier.height(6.dp)); AppLabel(label) }
        }
        return
    }
    val g = folderGeom(item.folderStyle, w, h, dens)
    val (shown, overflow) = folderVisible(item.folderStyle, item.children.size)
    Box(modifier) {
        Box(Modifier.matchParentSize().padding(4.dp).clip(RoundedCornerShape(30.dp)).background(Color.White.copy(alpha = 0.2f)))
        for (i in 0 until shown) {
            val r = g.rect(i)
            val key = item.children[i]
            val icon = with(d) { g.iconSize.toDp() }
            Box(
                Modifier.offset { IntOffset((r.left + (g.cell - g.iconSize) / 2f).toInt(), (r.top + (g.cell - g.iconSize) / 2f).toInt()) }
            ) { AppGlyph(key, icons, version, settings.iconShape, icon) }
        }
        if (overflow) {
            val r = g.rect(shown)
            val icon = with(d) { g.iconSize.toDp() }
            Box(
                Modifier.offset { IntOffset((r.left + (g.cell - g.iconSize) / 2f).toInt(), (r.top + (g.cell - g.iconSize) / 2f).toInt()) }
                    .size(icon).clip(CircleShape).background(Color.White.copy(alpha = 0.3f)),
                contentAlignment = Alignment.Center
            ) { Text("+${item.children.size - shown}", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp) }
        }
        Text(
            label, color = Color.White, fontSize = 12.sp, maxLines = 1,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp)
        )
    }
}

/** Full-screen blurred folder overlay with spring expansion. Tapping an icon launches it. */
@Composable
fun FolderOverlay(
    folder: HomeItem, appMap: Map<String, AppInfo>, icons: IconRepository, version: Int,
    settings: LauncherSettings, holder: WallpaperHolder,
    onLaunch: (AppInfo, Rect) -> Unit, onRemoveChild: (String) -> Unit, onDismiss: () -> Unit
) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val scale by animateFloatAsState(if (shown) 1f else 0.6f, Springs.page(), label = "folderScale")
    val alpha by animateFloatAsState(if (shown) 1f else 0f, Springs.shift(), label = "folderAlpha")
    val view = LocalView.current
    var removeKey by remember { mutableStateOf<String?>(null) }
    val apps = folder.children.mapNotNull { appMap[it] }

    Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { onDismiss() } }) {
        val api31 = Build.VERSION.SDK_INT >= 31
        Canvas(Modifier.fillMaxSize().graphicsLayer { this.alpha = alpha }.then(if (api31) Modifier.blur(28.dp) else Modifier)) {
            drawWallpaper(if (api31) holder.image else (holder.heavy ?: holder.image), 0.5f, false, size.width, size.height)
            drawRect(Color.Black.copy(alpha = 0.45f))
        }
        Column(
            Modifier.align(Alignment.Center).graphicsLayer { scaleX = scale; scaleY = scale; this.alpha = alpha }
                .widthIn(max = 680.dp).fillMaxWidth(0.8f).heightIn(max = 560.dp)
                .clip(RoundedCornerShape(40.dp)).background(Color.White.copy(alpha = 0.16f))
                .pointerInput(Unit) { detectTapGestures { removeKey = null } }
                .padding(28.dp)
        ) {
            Text(folder.title.ifEmpty { "Folder" }, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(16.dp))
            LazyVerticalGrid(GridCells.Adaptive(104.dp)) {
                items(apps, key = { it.key }) { app ->
                    var bounds by remember { mutableStateOf(Rect.Zero) }
                    Column(
                        Modifier.padding(6.dp).onGloballyPositioned { bounds = it.boundsInWindow() }
                            .pointerInput(app.key) {
                                detectTapGestures(
                                    onTap = { if (removeKey == app.key) removeKey = null else onLaunch(app, bounds) },
                                    onLongPress = { view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS); removeKey = app.key }
                                )
                            },
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        AppGlyph(app.key, icons, version, settings.iconShape, 64.dp * settings.iconScale)
                        Spacer(Modifier.height(6.dp))
                        AppLabel(app.label)
                        if (removeKey == app.key) {
                            Text(
                                "Move out", color = Color.White, fontSize = 11.sp,
                                modifier = Modifier.padding(top = 4.dp).clip(CircleShape).background(Color(0xCCE5484D))
                                    .pointerInput(app.key) { detectTapGestures { onRemoveChild(app.key); removeKey = null } }
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
