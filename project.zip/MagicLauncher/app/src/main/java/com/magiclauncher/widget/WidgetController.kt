package com.magiclauncher.widget

import android.app.Activity
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Context
import android.content.Intent
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ViewConfiguration
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import kotlin.math.hypot

/** AppWidgetHostView that reports a long-press (so the launcher can enter edit mode) without breaking widget touches. */
class LongPressHostView(ctx: Context) : AppWidgetHostView(ctx) {
    var onLongPress: (() -> Unit)? = null
    private var fired = false
    private var downX = 0f
    private var downY = 0f
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val runnable = Runnable {
        fired = true
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        onLongPress?.invoke()
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                fired = false; downX = ev.x; downY = ev.y
                postDelayed(runnable, ViewConfiguration.getLongPressTimeout().toLong())
            }
            MotionEvent.ACTION_MOVE -> if (hypot(ev.x - downX, ev.y - downY) > slop) removeCallbacks(runnable)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> removeCallbacks(runnable)
        }
        return fired
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean = if (fired) true else super.onTouchEvent(ev)
}

private class LauncherWidgetHost(ctx: Context) : AppWidgetHost(ctx, 1024) {
    override fun onCreateView(context: Context, appWidgetId: Int, appWidget: AppWidgetProviderInfo?): AppWidgetHostView =
        LongPressHostView(context)
}

/** Owns the AppWidgetHost and the bind -> configure -> add flow. Must be created before the activity is STARTED. */
class WidgetController(private val activity: ComponentActivity) {
    val host: AppWidgetHost = LauncherWidgetHost(activity)
    val manager: AppWidgetManager = AppWidgetManager.getInstance(activity)

    private var pendingId = -1
    private var pendingInfo: AppWidgetProviderInfo? = null
    private var pendingDone: ((Int) -> Unit)? = null

    private val bindLauncher = activity.registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) configureOrFinish() else cancel()
    }
    private val configLauncher = activity.registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) finish() else cancel()
    }

    fun start() { try { host.startListening() } catch (e: Exception) { } }
    fun stop() { try { host.stopListening() } catch (e: Exception) { } }

    fun providers(): List<AppWidgetProviderInfo> =
        manager.installedProviders.sortedBy { it.loadLabel(activity.packageManager).toString().lowercase() }

    fun createView(ctx: Context, id: Int): AppWidgetHostView? {
        val info = manager.getAppWidgetInfo(id) ?: return null
        return host.createView(ctx, id, info)
    }

    fun addWidget(info: AppWidgetProviderInfo, onReady: (Int) -> Unit) {
        val id = host.allocateAppWidgetId()
        pendingId = id; pendingInfo = info; pendingDone = onReady
        if (manager.bindAppWidgetIdIfAllowed(id, info.provider)) {
            configureOrFinish()
        } else {
            bindLauncher.launch(
                Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
            )
        }
    }

    private fun configureOrFinish() {
        val info = pendingInfo
        if (info?.configure != null) {
            try {
                configLauncher.launch(
                    Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE)
                        .setComponent(info.configure)
                        .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingId)
                )
                return
            } catch (e: Exception) { /* fall through: add without configuring */ }
        }
        finish()
    }

    private fun finish() { val id = pendingId; val cb = pendingDone; clear(); if (id >= 0) cb?.invoke(id) }
    private fun cancel() { if (pendingId >= 0) host.deleteAppWidgetId(pendingId); clear() }
    private fun clear() { pendingId = -1; pendingInfo = null; pendingDone = null }
}
