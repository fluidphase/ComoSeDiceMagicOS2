package com.magiclauncher

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.app.ActivityOptions
import android.content.Intent
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.content.pm.ShortcutInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.app.SearchManager
import android.graphics.Color as AColor
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.geometry.Rect
import com.magiclauncher.model.AppInfo
import com.magiclauncher.service.LauncherAccessibilityService
import com.magiclauncher.ui.HomeScreen
import com.magiclauncher.widget.WidgetController
import kotlinx.coroutines.flow.update
import kotlin.math.roundToInt

class LauncherActivity : ComponentActivity(), LauncherActions {
    private val vm: LauncherViewModel by viewModels()
    private lateinit var widgets: WidgetController
    private val launcherApps by lazy { getSystemService(LauncherApps::class.java) }
    private val wallpaperPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { vm.wallpaperVersion.update { it + 1 } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT)
        )
        widgets = WidgetController(this)
        vm.widgetDeleter = { widgets.host.deleteAppWidgetId(it) }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) { HomeScreen(vm, widgets, this@LauncherActivity) }
        }
        requestWallpaperPermission()
    }

    override fun onStart() { super.onStart(); widgets.start() }
    override fun onStop() { widgets.stop(); super.onStop() }
    override fun onDestroy() { vm.widgetDeleter = null; super.onDestroy() }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_HOME)) vm.goHome()
    }

    // ---- LauncherActions ----
    override fun launchApp(app: AppInfo, bounds: Rect?, newWindow: Boolean) {
        try {
            if (newWindow) {
                startActivity(
                    Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(app.component)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_MULTIPLE_TASK or Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT)
                )
                return
            }
            val src = bounds?.let {
                android.graphics.Rect(it.left.roundToInt(), it.top.roundToInt(), it.right.roundToInt(), it.bottom.roundToInt())
            }
            val opts = src?.let { ActivityOptions.makeScaleUpAnimation(window.decorView, it.left, it.top, it.width(), it.height()) }
            launcherApps.startMainActivity(app.component, app.user, src, opts?.toBundle())
        } catch (e: Exception) {
            Toast.makeText(this, "Can't open ${app.label}", Toast.LENGTH_SHORT).show()
        }
    }

    override fun startShortcut(s: ShortcutInfo) {
        try { launcherApps.startShortcut(s, null, null) } catch (e: Exception) { toast("Can't open shortcut") }
    }

    override fun appInfo(app: AppInfo) {
        try { launcherApps.startAppDetailsActivity(app.component, app.user, null, null) } catch (e: Exception) { toast("Unavailable") }
    }

    override fun uninstall(app: AppInfo) {
        startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.packageName}")))
    }

    private fun globalAction(action: Int, reflect: String?) {
        val svc = LauncherAccessibilityService.instance
        if (svc != null) { svc.performGlobalAction(action); return }
        if (reflect != null) {
            try {
                val sb = getSystemService("statusbar")
                Class.forName("android.app.StatusBarManager").getMethod(reflect).invoke(sb)
                return
            } catch (e: Throwable) { /* fall through */ }
        }
        toast("Enable “Magic Launcher gestures” in Accessibility settings")
        openAccessibilitySettings()
    }

    override fun expandNotifications() = globalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS, "expandNotificationsPanel")
    override fun expandQuickSettings() = globalAction(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS, "expandSettingsPanel")
    override fun lockScreen() = globalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN, null)

    override fun openUsageAccessSettings() { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    override fun openAccessibilitySettings() { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

    override fun requestWallpaperPermission() {
        if (Build.VERSION.SDK_INT < 33 &&
            checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) wallpaperPermission.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

    override fun webSearch(query: String) {
        try { startActivity(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, query).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { toast("No browser available") }
    }

    override fun openSystem(intent: Intent) {
        try { startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { toast("Unavailable") }
    }

    override fun isUsageAccessGranted() = vm.recentsRepo.hasUsageAccess()
    override fun isAccessibilityEnabled() = LauncherAccessibilityService.instance != null

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}
