package com.magiclauncher.ui

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Shape
import com.magiclauncher.model.IconShape
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sign
import kotlin.math.sin

val SquircleShape: Shape = GenericShape { size, _ ->
    val a = size.width / 2.0
    val b = size.height / 2.0
    val steps = 72
    for (i in 0..steps) {
        val t = 2.0 * PI * i / steps
        val c = cos(t); val s = sin(t)
        val x = a + a * sign(c) * abs(c).pow(0.5)
        val y = b + b * sign(s) * abs(s).pow(0.5)
        if (i == 0) moveTo(x.toFloat(), y.toFloat()) else lineTo(x.toFloat(), y.toFloat())
    }
    close()
}

fun IconShape.toShape(): Shape = when (this) {
    IconShape.CIRCLE -> CircleShape
    IconShape.SQUIRCLE -> SquircleShape
    IconShape.TEARDROP -> RoundedCornerShape(topStartPercent = 50, topEndPercent = 50, bottomEndPercent = 12, bottomStartPercent = 50)
    IconShape.MAGIC_ROUNDED -> RoundedCornerShape(percent = 30)
}
