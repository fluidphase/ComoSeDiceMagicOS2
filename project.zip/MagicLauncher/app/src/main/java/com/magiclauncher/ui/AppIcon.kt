package com.magiclauncher.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.magiclauncher.data.IconRepository
import com.magiclauncher.data.LoadedIcon
import com.magiclauncher.model.AppInfo
import com.magiclauncher.model.IconShape
import com.magiclauncher.model.LauncherSettings

@Composable
fun AppGlyph(key: String, icons: IconRepository, version: Int, shape: IconShape, size: Dp, modifier: Modifier = Modifier) {
    val loaded by produceState<LoadedIcon?>(initialValue = icons.peek(key), key, version) { value = icons.load(key) }
    val clipShape = if (loaded?.masked == false) RectangleShape else shape.toShape()
    Box(modifier.size(size).clip(clipShape)) {
        val l = loaded
        if (l != null) Image(bitmap = l.bitmap, contentDescription = null, modifier = Modifier.fillMaxSize())
        else Box(Modifier.fillMaxSize().background(Color.White.copy(alpha = 0.12f)))
    }
}

@Composable
fun AppLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text, color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
        style = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.6f), blurRadius = 6f)),
        modifier = modifier.padding(horizontal = 4.dp)
    )
}

/** Visual only: all gestures live on the wrapper (see itemGestures). */
@Composable
fun AppIconCell(
    app: AppInfo, icons: IconRepository, version: Int, settings: LauncherSettings,
    w: Dp, h: Dp, modifier: Modifier = Modifier
) {
    val base = minOf(minOf(w, h) * 0.58f, 76.dp) * settings.iconScale
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        AppGlyph(app.key, icons, version, settings.iconShape, base)
        if (settings.showLabels) {
            Spacer(Modifier.height(6.dp))
            AppLabel(app.label)
        }
    }
}

@Composable
fun GlassCard(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    Box(modifier.clip(RoundedCornerShape(28.dp)).background(Color.White.copy(alpha = 0.18f)), content = content)
}
