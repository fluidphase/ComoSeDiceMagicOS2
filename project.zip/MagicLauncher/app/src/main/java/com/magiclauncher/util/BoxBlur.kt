package com.magiclauncher.util

import android.graphics.Bitmap

/**
 * Pure-Kotlin, O(n) box blur (3 passes ≈ gaussian). Used as the API 29/30 fallback for the glass dock and
 * the folder overlay, where RenderEffect (API 31+) doesn't exist. Works on a down-scaled copy, so it is cheap.
 */
object BoxBlur {
    fun blur(src: Bitmap, radius: Int, passes: Int = 3): Bitmap {
        val w = src.width; val h = src.height
        val a = IntArray(w * h)
        src.getPixels(a, 0, w, 0, 0, w, h)
        val b = IntArray(w * h)
        val r = radius.coerceAtLeast(1)
        repeat(passes) {
            pass(a, b, h, w, w, 1, r)   // horizontal
            pass(b, a, w, h, 1, w, r)   // vertical
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(a, 0, w, 0, 0, w, h)
        return out
    }

    private fun pass(src: IntArray, dst: IntArray, lines: Int, len: Int, lineStep: Int, elemStep: Int, r: Int) {
        val div = 2 * r + 1
        for (l in 0 until lines) {
            val base = l * lineStep
            var sa = 0; var sr = 0; var sg = 0; var sb = 0
            for (i in -r..r) {
                val p = src[base + i.coerceIn(0, len - 1) * elemStep]
                sa += p ushr 24; sr += (p shr 16) and 255; sg += (p shr 8) and 255; sb += p and 255
            }
            for (i in 0 until len) {
                dst[base + i * elemStep] = ((sa / div) shl 24) or ((sr / div) shl 16) or ((sg / div) shl 8) or (sb / div)
                val add = src[base + (i + r + 1).coerceAtMost(len - 1) * elemStep]
                val rem = src[base + (i - r).coerceAtLeast(0) * elemStep]
                sa += (add ushr 24) - (rem ushr 24)
                sr += ((add shr 16) and 255) - ((rem shr 16) and 255)
                sg += ((add shr 8) and 255) - ((rem shr 8) and 255)
                sb += (add and 255) - (rem and 255)
            }
        }
    }
}
