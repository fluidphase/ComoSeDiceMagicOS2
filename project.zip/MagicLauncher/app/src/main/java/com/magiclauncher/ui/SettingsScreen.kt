@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.magiclauncher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.magiclauncher.LauncherActions
import com.magiclauncher.data.IconPackInfo
import com.magiclauncher.model.*
import kotlin.math.roundToInt

private enum class Page(val title: String) {
    DESKTOP("Desktop"), ICONS("Icons"), DOCK("Dock"), FOLDERS("Folders & weather"), GESTURES("Gestures"), SYSTEM("Permissions")
}

/** Two-pane settings (categories left, options right) sized for tablets. */
@Composable
fun SettingsScreen(
    settings: LauncherSettings,
    onChange: ((LauncherSettings) -> LauncherSettings) -> Unit,
    packs: List<IconPackInfo>,
    usageGranted: Boolean, a11yEnabled: Boolean,
    actions: LauncherActions, onClose: () -> Unit
) {
    var page by remember { mutableStateOf(Page.DESKTOP) }
    Box(Modifier.fillMaxSize().background(Color(0xF2101218)).pointerInput(Unit) { detectTapGestures { } }) {
        Row(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars).padding(24.dp)) {
            Column(Modifier.width(260.dp).fillMaxHeight()) {
                Text("Launcher settings", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(16.dp))
                Page.entries.forEach { p ->
                    Text(
                        p.title, color = Color.White, fontSize = 16.sp,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(16.dp))
                            .background(if (p == page) Color.White.copy(alpha = 0.16f) else Color.Transparent)
                            .pointerInput(p) { detectTapGestures { page = p } }.padding(16.dp)
                    )
                }
                Spacer(Modifier.weight(1f))
                Button(onClick = onClose) { Text("Done") }
            }
            Spacer(Modifier.width(24.dp))
            Column(Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState())) {
                when (page) {
                    Page.DESKTOP -> Desktop(settings, onChange)
                    Page.ICONS -> Icons(settings, onChange, packs)
                    Page.DOCK -> Dock(settings, onChange)
                    Page.FOLDERS -> Folders(settings, onChange)
                    Page.GESTURES -> Gestures(settings, onChange)
                    Page.SYSTEM -> System(usageGranted, a11yEnabled, actions)
                }
            }
        }
    }
}

@Composable private fun Title(t: String) = Text(t, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 12.dp))

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, modifier = Modifier.weight(1f))
        Switch(checked, onChange)
    }
}

@Composable
private fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, steps: Int, display: String, onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Row { Text(label, color = Color.White, modifier = Modifier.weight(1f)); Text(display, color = Color.White.copy(alpha = 0.7f)) }
        Slider(value, onChange, valueRange = range, steps = steps)
    }
}

@Composable
private fun <T> Chips(options: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 6.dp)) {
        options.forEach { o -> FilterChip(o == selected, { onSelect(o) }, { Text(label(o)) }) }
    }
}

@Composable
private fun Desktop(s: LauncherSettings, set: ((LauncherSettings) -> LauncherSettings) -> Unit) {
    Title("Desktop grid")
    val presets = listOf(4 to 5, 4 to 6, 5 to 5, 5 to 6, 6 to 5, 7 to 5, 8 to 5)
    Chips(presets, s.gridCols to s.gridRows, { "${it.first}×${it.second}" }) { p -> set { it.copy(gridCols = p.first, gridRows = p.second) } }
    SliderRow("Columns (N)", s.gridCols.toFloat(), 3f..10f, 6, "${s.gridCols}") { v -> set { it.copy(gridCols = v.roundToInt()) } }
    SliderRow("Rows (M)", s.gridRows.toFloat(), 3f..8f, 4, "${s.gridRows}") { v -> set { it.copy(gridRows = v.roundToInt()) } }
    SwitchRow("Parallax wallpaper", s.parallax) { v -> set { it.copy(parallax = v) } }
}

@Composable
private fun Icons(s: LauncherSettings, set: ((LauncherSettings) -> LauncherSettings) -> Unit, packs: List<IconPackInfo>) {
    Title("Icon style")
    Chips(IconShape.entries.toList(), s.iconShape, { it.label }) { v -> set { it.copy(iconShape = v) } }
    SliderRow("Icon size", s.iconScale, 0.8f..1.2f, 7, "${(s.iconScale * 100).roundToInt()}%") { v -> set { it.copy(iconScale = (v * 20).roundToInt() / 20f) } }
    SwitchRow("Show icon labels", s.showLabels) { v -> set { it.copy(showLabels = v) } }
    Text("Icon pack", color = Color.White, modifier = Modifier.padding(top = 12.dp))
    val options = listOf<String?>(null) + packs.map { it.pkg }
    Chips(options, s.iconPack, { p -> if (p == null) "System default" else packs.first { it.pkg == p }.label }) { v -> set { it.copy(iconPack = v) } }
    if (packs.isEmpty()) Text("No ADW/Nova-compatible icon packs installed.", color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp)
}

@Composable
private fun Dock(s: LauncherSettings, set: ((LauncherSettings) -> LauncherSettings) -> Unit) {
    Title("Dock")
    SwitchRow("Glass blur", s.dockBlurEnabled) { v -> set { it.copy(dockBlurEnabled = v) } }
    SliderRow("Blur radius", s.dockBlurRadiusDp.toFloat(), 0f..30f, 29, "${s.dockBlurRadiusDp}dp") { v -> set { it.copy(dockBlurRadiusDp = v.roundToInt()) } }
    SliderRow("Tint opacity", s.dockTintAlpha, 0f..0.6f, 0, "${(s.dockTintAlpha * 100).roundToInt()}%") { v -> set { it.copy(dockTintAlpha = v) } }
    SwitchRow("Show recent apps", s.dockShowRecents) { v -> set { it.copy(dockShowRecents = v) } }
    SliderRow("Max recent apps", s.dockMaxRecents.toFloat(), 1f..4f, 2, "${s.dockMaxRecents}") { v -> set { it.copy(dockMaxRecents = v.roundToInt()) } }
    SwitchRow("Floating dock (off = edge-to-edge)", s.dockFloating) { v -> set { it.copy(dockFloating = v) } }
}

@Composable
private fun Folders(s: LauncherSettings, set: ((LauncherSettings) -> LauncherSettings) -> Unit) {
    Title("New folders")
    Chips(FolderStyle.entries.toList(), s.defaultFolderStyle, { it.label }) { v -> set { it.copy(defaultFolderStyle = v) } }
    Title("Weather card location")
    var lat by remember { mutableStateOf(s.weatherLat.toString()) }
    var lon by remember { mutableStateOf(s.weatherLon.toString()) }
    OutlinedTextField(lat, { lat = it; it.toDoubleOrNull()?.let { d -> set { s0 -> s0.copy(weatherLat = d) } } },
        label = { Text("Latitude") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
    Spacer(Modifier.height(8.dp))
    OutlinedTextField(lon, { lon = it; it.toDoubleOrNull()?.let { d -> set { s0 -> s0.copy(weatherLon = d) } } },
        label = { Text("Longitude") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
}

@Composable
private fun Gestures(s: LauncherSettings, set: ((LauncherSettings) -> LauncherSettings) -> Unit) {
    Title("Gestures")
    SwitchRow("Swipe down: notifications (left) / control center (right)", s.gestureSwipeDown) { v -> set { it.copy(gestureSwipeDown = v) } }
    SwitchRow("Swipe up", s.gestureSwipeUp) { v -> set { it.copy(gestureSwipeUp = v) } }
    Chips(SwipeUpAction.entries.toList(), s.swipeUpAction, { it.label }) { v -> set { it.copy(swipeUpAction = v) } }
    SwitchRow("Pinch in: home screen editing", s.gesturePinch) { v -> set { it.copy(gesturePinch = v) } }
    SwitchRow("Double tap: lock screen", s.gestureDoubleTap) { v -> set { it.copy(gestureDoubleTap = v) } }
}

@Composable
private fun System(usage: Boolean, a11y: Boolean, actions: LauncherActions) {
    Title("Permissions")
    Text("Recent apps in the dock use Usage access. Notification panel, control center and lock-screen gestures use the accessibility service (it never reads screen content).",
        color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp)
    Spacer(Modifier.height(12.dp))
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Usage access: ${if (usage) "granted" else "not granted"}", color = Color.White, modifier = Modifier.weight(1f))
        Button(onClick = actions::openUsageAccessSettings) { Text("Open") }
    }
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
        Text("Gesture service: ${if (a11y) "enabled" else "disabled"}", color = Color.White, modifier = Modifier.weight(1f))
        Button(onClick = actions::openAccessibilitySettings) { Text("Open") }
    }
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
        Text("Wallpaper access (Android ≤12)", color = Color.White, modifier = Modifier.weight(1f))
        Button(onClick = actions::requestWallpaperPermission) { Text("Grant") }
    }
}
