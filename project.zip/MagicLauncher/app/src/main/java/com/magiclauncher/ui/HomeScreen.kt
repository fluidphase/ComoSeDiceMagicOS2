package com.magiclauncher.ui

import android.view.HapticFeedbackConstants
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntOffsetAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerDefaults
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.magiclauncher.LauncherActions
import com.magiclauncher.LauncherViewModel
import com.magiclauncher.data.IconRepository
import com.magiclauncher.model.*
import com.magiclauncher.widget.WidgetController
import kotlinx.coroutines.delay
import kotlin.math.max
import kotlin.math.roundToInt

private class DragLocal { var started = false; var accum = Offset.Zero }

@Composable
fun HomeScreen(vm: LauncherViewModel, widgets: WidgetController, actions: LauncherActions) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val items by vm.items.collectAsStateWithLifecycle()
    val preview by vm.preview.collectAsStateWithLifecycle()
    val drag by vm.drag.collectAsStateWithLifecycle()
    val apps by vm.apps.collectAsStateWithLifecycle()
    val dockKeys by vm.dock.collectAsStateWithLifecycle()
    val recentKeys by vm.recents.collectAsStateWithLifecycle()
    val iconVersion by vm.iconVersion.collectAsStateWithLifecycle()
    val wallVersion by vm.wallpaperVersion.collectAsStateWithLifecycle()
    val appMap = remember(apps) { apps.associateBy { it.key } }
    val view = LocalView.current
    val holder = rememberWallpaper(settings.dockBlurRadiusDp, wallVersion)
    var permTick by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.refreshRecents(); permTick++ }

    BackHandler(enabled = vm.menuTarget != null || vm.anyOverlay || vm.editMode) {
        when {
            vm.menuTarget != null -> vm.menuTarget = null
            vm.showWidgetPicker -> vm.showWidgetPicker = false
            vm.showSettings -> vm.showSettings = false
            vm.openFolderId != null -> vm.openFolderId = null
            vm.showDrawer -> vm.showDrawer = false
            else -> { vm.editMode = false; vm.selectedId = null }
        }
    }

    val displayItems = preview ?: items
    val dd = drag
    val pageCount = (items.maxOfOrNull { it.page } ?: 0) + 1 + (if (dd != null && !dd.dropping) 1 else 0)
    val pagerState = rememberPagerState { pageCount }
    LaunchedEffect(pagerState) { snapshotFlow { pagerState.currentPage }.collect { vm.onPageChanged(it) } }
    LaunchedEffect(vm.homeEvent) { if (vm.homeEvent > 0) pagerState.animateScrollToPage(0, animationSpec = Springs.page()) }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val rootSize = IntSize(constraints.maxWidth, constraints.maxHeight)
        val rootW = constraints.maxWidth.toFloat()
        val sys = WindowInsets.systemBars.asPaddingValues()
        val progress: () -> Float = {
            if (pagerState.pageCount <= 1) 0.5f
            else ((pagerState.currentPage + pagerState.currentPageOffsetFraction) / (pagerState.pageCount - 1)).coerceIn(0f, 1f)
        }

        Canvas(Modifier.fillMaxSize()) {
            drawWallpaper(holder.image, progress(), settings.parallax, size.width, size.height)
            drawRect(Color.Black.copy(alpha = 0.16f))
        }

        GestureContainer(
            Modifier.fillMaxSize(),
            enabled = drag == null && !vm.anyOverlay && !vm.editMode,
            swipeDown = settings.gestureSwipeDown, swipeUp = settings.gestureSwipeUp, pinch = settings.gesturePinch,
            onSwipeDown = { x -> if (x > rootW / 2f) actions.expandQuickSettings() else actions.expandNotifications() },
            onSwipeUp = { vm.openDrawer(settings.swipeUpAction == SwipeUpAction.GLOBAL_SEARCH) },
            onPinchIn = { view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS); vm.editMode = true }
        ) {
            var gridSize by remember { mutableStateOf(IntSize.Zero) }
            val cols = settings.gridCols; val rows = settings.gridRows
            val cellW = if (gridSize.width > 0) gridSize.width.toFloat() / cols else 1f
            val cellH = if (gridSize.height > 0) gridSize.height.toFloat() / rows else 1f
            LaunchedEffect(cellW, cellH) { vm.setGeometry(cellW, cellH) }
            val editScale by animateFloatAsState(if (vm.editMode) 0.9f else 1f, Springs.pop(), label = "editScale")

            // edge-dwell: hold a dragged item at a side edge to flip pages
            val edge = if (dd == null || dd.dropping) 0 else {
                val cx = dd.offset.x + dd.item.spanX * cellW / 2f
                if (cx < cellW * 0.25f) -1 else if (cx > gridSize.width - cellW * 0.25f) 1 else 0
            }
            LaunchedEffect(edge, pagerState.currentPage) {
                if (edge != 0) {
                    delay(650)
                    val t = pagerState.currentPage + edge
                    if (t in 0 until pagerState.pageCount) pagerState.animateScrollToPage(t, animationSpec = Springs.page())
                }
            }

            Box(
                Modifier.fillMaxSize()
                    .padding(start = 40.dp, end = 40.dp, top = sys.calculateTopPadding() + 72.dp, bottom = sys.calculateBottomPadding() + 150.dp)
                    .onSizeChanged { gridSize = it }
                    .graphicsLayer { scaleX = editScale; scaleY = editScale }
            ) {
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier.fillMaxSize(),
                    userScrollEnabled = drag == null,
                    beyondViewportPageCount = pageCount,
                    flingBehavior = PagerDefaults.flingBehavior(pagerState, snapAnimationSpec = Springs.page())
                ) { page ->
                    val dragId = dd?.item?.id
                    val hiddenItem: HomeItem? = if (dd == null) null else if (dd.dropping) (items.firstOrNull { it.id == dragId } ?: dd.item) else dd.item
                    val pageItems = displayItems.filter { it.page == page && it.id != dragId } +
                        listOfNotNull(hiddenItem?.takeIf { it.page == page })
                    Box(Modifier.fillMaxSize()) {
                        Box(
                            Modifier.fillMaxSize().emptySpaceGestures(
                                onDoubleTap = { if (settings.gestureDoubleTap && !vm.editMode) actions.lockScreen() },
                                onLongPress = { view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS); vm.editMode = true },
                                onTap = { vm.selectedId = null }
                            )
                        )
                        for (item in pageItems) key(item.id) {
                            HomeItemView(
                                item, vm, widgets, actions, settings, appMap, cellW, cellH,
                                editMode = vm.editMode, hidden = item.id == dragId,
                                merging = dd?.mergeTargetId == item.id, selected = vm.selectedId == item.id,
                                iconVersion = iconVersion
                            )
                        }
                    }
                }
                if (dd != null) DragOverlay(dd, vm, appMap, widgets, settings, cellW, cellH, iconVersion)
            }

            // remove zone
            if (dd != null && !dd.dropping) {
                val hover = dd.offset.y + dd.item.spanY * cellH / 2f < 0f
                Box(
                    Modifier.align(Alignment.TopCenter).padding(top = sys.calculateTopPadding() + 12.dp)
                        .clip(RoundedCornerShape(24.dp)).background(if (hover) Color(0xCCE5484D) else Color(0x66000000))
                        .padding(horizontal = 24.dp, vertical = 12.dp)
                ) { Text("🗑  Remove", color = Color.White) }
            }

            // page dots / edit toolbar
            Box(Modifier.align(Alignment.BottomCenter).padding(bottom = sys.calculateBottomPadding() + 128.dp)) {
                if (vm.editMode) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Pill("＋ Widgets") { vm.showWidgetPicker = true }
                        Pill("⚙ Settings") { vm.showSettings = true }
                        Pill("Done", primary = true) { vm.editMode = false; vm.selectedId = null }
                    }
                } else if (pageCount > 1) {
                    Row {
                        repeat(pageCount) { i ->
                            val active = pagerState.currentPage == i
                            val w by animateDpAsState(if (active) 18.dp else 7.dp, Springs.pop(), label = "dot")
                            Box(Modifier.padding(3.dp).height(7.dp).width(w).clip(CircleShape).background(Color.White.copy(alpha = if (active) 0.95f else 0.45f)))
                        }
                    }
                }
            }

            // dock
            val pinned = dockKeys.mapNotNull { appMap[it] }
            val recents = recentKeys.mapNotNull { appMap[it] }.take(settings.dockMaxRecents)
            DynamicDock(
                pinned, recents, settings, holder, rootSize, progress, vm.icons, iconVersion, sys.calculateBottomPadding(),
                onTap = { app, b -> vm.launch(app, b, actions) },
                onLongPress = { app -> vm.menuTarget = "dock:${app.key}" },
                menuFor = { app ->
                    if (vm.menuTarget == "dock:${app.key}") {
                        val isPinned = app.key in dockKeys
                        AppMenu(
                            app, vm, actions,
                            if (isPinned) listOf(
                                MenuAction("Unpin from dock") { vm.unpinFromDock(app.key) },
                                MenuAction("Move left") { vm.moveDock(app.key, -1) },
                                MenuAction("Move right") { vm.moveDock(app.key, 1) }
                            ) else listOf(MenuAction("Pin to dock") { vm.pinToDock(app.key) })
                        )
                    }
                },
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }

        // back-layer dimming while a context menu is open
        AnimatedVisibility(vm.menuTarget != null, enter = fadeIn(), exit = fadeOut()) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f)))
        }

        // overlays
        vm.openFolderId?.let { id ->
            items.firstOrNull { it.id == id }?.let { f ->
                FolderOverlay(f, appMap, vm.icons, iconVersion, settings, holder,
                    onLaunch = { app, b -> vm.launch(app, b, actions) },
                    onRemoveChild = { vm.removeFromFolder(f.id, it) },
                    onDismiss = { vm.openFolderId = null })
            }
        }
        AnimatedVisibility(
            vm.showDrawer,
            enter = slideInVertically(Springs.page()) { it / 2 } + fadeIn(),
            exit = slideOutVertically { it / 2 } + fadeOut()
        ) {
            AppDrawer(apps, vm.icons, iconVersion, settings, holder, vm.drawerFocusSearch,
                onLaunch = { app, b -> vm.launch(app, b, actions) },
                onAddHome = { vm.addAppToHome(it.key); vm.showDrawer = false },
                onPin = { vm.pinToDock(it.key); vm.showDrawer = false },
                onInfo = { actions.appInfo(it) }, onUninstall = { actions.uninstall(it) },
                onWebSearch = { actions.webSearch(it) })
        }
        AnimatedVisibility(
            vm.showWidgetPicker,
            enter = slideInHorizontally(Springs.page()) { it } + fadeIn(),
            exit = slideOutHorizontally { it } + fadeOut()
        ) {
            val cw = (rootW - with(LocalDensity.current) { 80.dp.toPx() }) / settings.gridCols
            val ch = (constraints.maxHeight - with(LocalDensity.current) { 222.dp.toPx() }) / settings.gridRows
            WidgetPicker(widgets, cw, ch, settings.gridCols, settings.gridRows,
                onMagic = { vm.addMagic(it); vm.showWidgetPicker = false },
                onProvider = { info, sx, sy ->
                    vm.showWidgetPicker = false
                    widgets.addWidget(info) { id -> vm.addAppWidget(id, sx, sy) }
                },
                onDismiss = { vm.showWidgetPicker = false })
        }
        AnimatedVisibility(vm.showSettings, enter = fadeIn() + slideInVertically(Springs.page()) { it / 4 }, exit = fadeOut()) {
            val ctx = androidx.compose.ui.platform.LocalContext.current
            val packs = remember { IconRepository.availablePacks(ctx) }
            val usage = remember(permTick, vm.showSettings) { actions.isUsageAccessGranted() }
            val a11y = remember(permTick, vm.showSettings) { actions.isAccessibilityEnabled() }
            SettingsScreen(settings, { t -> vm.updateSettings(t) }, packs, usage, a11y, actions) { vm.showSettings = false }
        }
        vm.launchAnim?.let { LaunchTransition(it) { vm.launchAnim = null } }
    }
}

@Composable
private fun Pill(text: String, primary: Boolean = false, onClick: () -> Unit) {
    Text(
        text, color = Color.White, fontSize = 15.sp,
        modifier = Modifier.clip(CircleShape).background(if (primary) Color(0xFF3B3FD9) else Color(0x88000000))
            .pointerInput(Unit) { detectTapGestures { onClick() } }.padding(horizontal = 20.dp, vertical = 10.dp)
    )
}

// ------------------------------------------------------------------ a single home-screen item

@Composable
private fun HomeItemView(
    item: HomeItem, vm: LauncherViewModel, widgets: WidgetController, actions: LauncherActions,
    settings: LauncherSettings, appMap: Map<String, AppInfo>, cellW: Float, cellH: Float,
    editMode: Boolean, hidden: Boolean, merging: Boolean, selected: Boolean, iconVersion: Int
) {
    val density = LocalDensity.current
    val view = LocalView.current
    val target = IntOffset((item.col * cellW).roundToInt(), (item.row * cellH).roundToInt())
    val pos by animateIntOffsetAsState(target, Springs.shift(), label = "itemPos")   // items slide out of the way
    val wPx = item.spanX * cellW
    val hPx = item.spanY * cellH
    val wDp = with(density) { wPx.toDp() }
    val hDp = with(density) { hPx.toDp() }
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (merging) 1.12f else if (pressed && !editMode) 0.93f else 1f, Springs.pop(), label = "itemScale")
    var bounds by remember { mutableStateOf(Rect.Zero) }
    val slop = with(density) { 10.dp.toPx() }
    val local = remember { DragLocal() }

    val onDragStart: () -> Unit = {
        local.started = false; local.accum = Offset.Zero
        view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        if (editMode) { local.started = true; vm.startDrag(item) } else if (item.kind != ItemKind.WIDGET) vm.menuTarget = item.id
    }
    val onDrag: (Offset) -> Unit = { d ->
        if (!local.started) {
            local.accum += d
            if (local.accum.getDistance() > slop) {
                local.started = true; vm.menuTarget = null; vm.startDrag(item); vm.dragBy(local.accum)
            }
        } else vm.dragBy(d)
    }
    val onDragEnd: () -> Unit = { if (local.started) vm.endDrag(); local.started = false }
    val onTap: (Offset) -> Unit = { off ->
        if (!editMode) when (item.kind) {
            ItemKind.APP -> appMap[item.key]?.let { vm.launch(it, bounds, actions) }
            ItemKind.FOLDER -> when (val hit = folderHit(item, wPx, hPx, density.density, off)) {
                is FolderHit.Child -> item.children.getOrNull(hit.index)?.let { k ->
                    appMap[k]?.let { app ->
                        val r = folderGeom(item.folderStyle, wPx, hPx, density.density).rect(hit.index)
                        vm.launch(app, Rect(bounds.left + r.left, bounds.top + r.top, bounds.left + r.right, bounds.top + r.bottom), actions)
                    }
                }
                else -> vm.openFolderId = item.id
            }
            ItemKind.WIDGET -> {}
        }
    }

    val gestureMod = if (item.kind != ItemKind.WIDGET) {
        Modifier.itemGestures(editMode, { pressed = it }, onTap, onDragStart, onDrag, onDragEnd)
    } else Modifier

    Box(
        Modifier.offset { pos }.size(wDp, hDp)
            .graphicsLayer { alpha = if (hidden) 0f else 1f; scaleX = scale; scaleY = scale }
            .onGloballyPositioned { bounds = it.boundsInWindow() }
            .then(gestureMod)
    ) {
        when (item.kind) {
            ItemKind.APP -> appMap[item.key]?.let { AppIconCell(it, vm.icons, iconVersion, settings, wDp, hDp, Modifier.fillMaxSize()) }
            ItemKind.FOLDER -> FolderCell(item, appMap, vm.icons, iconVersion, settings, wPx, hPx, Modifier.fillMaxSize())
            ItemKind.WIDGET -> {
                WidgetItem(item, widgets, settings, wDp, hDp, editMode,
                    onLongPress = { vm.editMode = true; vm.selectedId = item.id },
                    onMagicTap = { t -> openMagic(t, actions) })
                if (editMode) {
                    WidgetEditOverlay(
                        item, selected, cellW, cellH, settings.gridCols, settings.gridRows,
                        onSelect = { vm.selectedId = item.id }, onPress = { pressed = it },
                        onDragStart = { vm.selectedId = item.id; onDragStart() }, onDrag = onDrag, onDragEnd = onDragEnd,
                        onResize = { sx, sy -> vm.resizeItem(item.id, sx, sy) },
                        onRemove = { vm.removeItem(item.id) }, onUnstack = { vm.unstack(item.id) }
                    )
                }
            }
        }
        if (vm.menuTarget == item.id) {
            when (item.kind) {
                ItemKind.APP -> appMap[item.key]?.let { app ->
                    AppMenu(app, vm, actions, listOf(
                        MenuAction("Create big folder") { vm.makeFolder(item.id) },
                        MenuAction("Pin to dock") { vm.pinToDock(app.key) },
                        MenuAction("Edit home screen") { vm.editMode = true },
                        MenuAction("Remove from home") { vm.removeItem(item.id) }
                    ))
                }
                ItemKind.FOLDER -> FolderMenu(item, vm)
                ItemKind.WIDGET -> {}
            }
        }
    }
}

private fun openMagic(t: MagicWidgetType, actions: LauncherActions) {
    val i = when (t) {
        MagicWidgetType.CLOCK -> android.content.Intent(android.provider.AlarmClock.ACTION_SHOW_ALARMS)
        MagicWidgetType.BATTERY -> android.content.Intent(android.content.Intent.ACTION_POWER_USAGE_SUMMARY)
        MagicWidgetType.STORAGE -> android.content.Intent(android.provider.Settings.ACTION_INTERNAL_STORAGE_SETTINGS)
        MagicWidgetType.WEATHER -> null
    }
    if (i != null) actions.openSystem(i)
}

// ------------------------------------------------------------------ the item being dragged (above all pages)

@Composable
private fun DragOverlay(
    d: DragState, vm: LauncherViewModel, appMap: Map<String, AppInfo>, widgets: WidgetController,
    settings: LauncherSettings, cellW: Float, cellH: Float, iconVersion: Int
) {
    val density = LocalDensity.current
    val off = remember { Animatable(d.offset, Offset.VectorConverter) }
    var settling by remember { mutableStateOf(false) }
    LaunchedEffect(d.dropping) {
        if (d.dropping) {
            val t = d.settleTo
            if (t == null) vm.clearDrag() else {
                off.snapTo(d.offset); settling = true
                off.animateTo(t, Springs.page())      // LowBouncy + StiffnessLow settle
                vm.clearDrag()
            }
        }
    }
    val p = if (settling) off.value else d.offset
    val item = d.item
    val wPx = item.spanX * cellW; val hPx = item.spanY * cellH
    val wDp = with(density) { wPx.toDp() }; val hDp = with(density) { hPx.toDp() }
    Box(
        Modifier.offset { IntOffset(p.x.roundToInt(), p.y.roundToInt()) }.size(wDp, hDp)
            .graphicsLayer { val s = if (d.dropping) 1f else 1.08f; scaleX = s; scaleY = s; alpha = 0.96f }
    ) {
        when (item.kind) {
            ItemKind.APP -> appMap[item.key]?.let { AppIconCell(it, vm.icons, iconVersion, settings, wDp, hDp, Modifier.fillMaxSize()) }
            ItemKind.FOLDER -> FolderCell(item, appMap, vm.icons, iconVersion, settings, wPx, hPx, Modifier.fillMaxSize())
            ItemKind.WIDGET -> {
                val ref = item.widgets.firstOrNull()
                if (ref?.magic != null) WidgetItem(item, widgets, settings, wDp, hDp, true, {}, {})
                else Box(
                    Modifier.fillMaxSize().padding(4.dp).clip(RoundedCornerShape(24.dp)).background(Color(0x99222733))
                        .border(1.dp, Color.White.copy(alpha = 0.4f), RoundedCornerShape(24.dp)),
                    contentAlignment = Alignment.Center
                ) { Text("▦ Widget", color = Color.White) }
            }
        }
    }
}
