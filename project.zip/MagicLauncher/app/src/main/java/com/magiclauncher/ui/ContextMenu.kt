package com.magiclauncher.ui

import android.content.pm.ShortcutInfo
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.*
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupPositionProvider
import androidx.compose.ui.window.PopupProperties
import com.magiclauncher.LauncherActions
import com.magiclauncher.LauncherViewModel
import com.magiclauncher.model.AppInfo
import com.magiclauncher.model.FolderStyle
import com.magiclauncher.model.HomeItem
import kotlinx.coroutines.launch
import kotlin.math.max

data class MenuAction(val label: String, val destructive: Boolean = false, val onClick: () -> Unit)
data class ShortcutEntry(val info: ShortcutInfo, val icon: ImageBitmap?)

private class AnchorBelowProvider(private val gap: Int) : PopupPositionProvider {
    override fun calculatePosition(anchorBounds: IntRect, windowSize: IntSize, layoutDirection: LayoutDirection, popupContentSize: IntSize): IntOffset {
        val x = (anchorBounds.center.x - popupContentSize.width / 2)
            .coerceIn(16, max(16, windowSize.width - popupContentSize.width - 16))
        var y = anchorBounds.bottom + gap
        if (y + popupContentSize.height > windowSize.height - 16) y = anchorBounds.top - gap - popupContentSize.height
        return IntOffset(x, y.coerceAtLeast(16))
    }
}

/** Popup menu with a bounce/scale spring. Anchored to the composable that calls it. */
@Composable
fun MenuPopup(
    shortcuts: List<ShortcutEntry>, actions: List<MenuAction>,
    onShortcut: (ShortcutInfo) -> Unit, onDismiss: () -> Unit
) {
    val gap = with(LocalDensity.current) { 10.dp.roundToPx() }
    Popup(
        popupPositionProvider = remember { AnchorBelowProvider(gap) },
        onDismissRequest = onDismiss,
        properties = PopupProperties(focusable = true)
    ) {
        val sc = remember { Animatable(0.55f) }
        val al = remember { Animatable(0f) }
        LaunchedEffect(Unit) {
            launch { al.animateTo(1f, tween(120)) }
            sc.animateTo(1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium))
        }
        Surface(
            Modifier.graphicsLayer {
                scaleX = sc.value; scaleY = sc.value; alpha = al.value
                transformOrigin = TransformOrigin(0.5f, 0f)
            }.width(272.dp),
            shape = RoundedCornerShape(24.dp), color = Color(0xF2202228), shadowElevation = 16.dp
        ) {
            Column(Modifier.padding(8.dp)) {
                shortcuts.forEach { s ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onShortcut(s.info) }.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        s.icon?.let { Image(it, null, Modifier.size(24.dp)); Spacer(Modifier.width(12.dp)) }
                        Text(s.info.shortLabel?.toString() ?: "", color = Color.White, maxLines = 1)
                    }
                }
                if (shortcuts.isNotEmpty()) HorizontalDivider(color = Color.White.copy(alpha = 0.15f))
                actions.forEach { a ->
                    Text(
                        a.label,
                        color = if (a.destructive) Color(0xFFFF6B6B) else Color.White,
                        modifier = Modifier.fillMaxWidth().clickable { a.onClick() }.padding(12.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun AppMenu(
    app: AppInfo, vm: LauncherViewModel, actions: LauncherActions, extra: List<MenuAction>
) {
    val shortcuts by produceState(emptyList<ShortcutEntry>(), app.key) { value = vm.shortcutsFor(app) }
    val close = { vm.menuTarget = null }
    val all = extra + listOf(
        MenuAction("App info") { actions.appInfo(app) },
        MenuAction("Open in new window") { actions.launchApp(app, null, newWindow = true) },
        MenuAction("Uninstall", destructive = true) { actions.uninstall(app) }
    )
    MenuPopup(
        shortcuts = shortcuts,
        actions = all.map { a -> a.copy(onClick = { close(); a.onClick() }) },
        onShortcut = { close(); actions.startShortcut(it) },
        onDismiss = close
    )
}

@Composable
fun FolderMenu(item: HomeItem, vm: LauncherViewModel) {
    val close = { vm.menuTarget = null }
    val styles = FolderStyle.entries.map { st ->
        MenuAction((if (item.folderStyle == st) "✓  " else "     ") + st.label) { close(); vm.setFolderStyle(item.id, st) }
    }
    MenuPopup(
        shortcuts = emptyList(),
        actions = listOf(MenuAction("Open folder") { close(); vm.openFolderId = item.id }) + styles + listOf(
            MenuAction("Edit home screen") { close(); vm.editMode = true },
            MenuAction("Dissolve folder") { close(); vm.dissolveFolder(item.id) },
            MenuAction("Remove", destructive = true) { close(); vm.removeItem(item.id) }
        ),
        onShortcut = {}, onDismiss = close
    )
}
