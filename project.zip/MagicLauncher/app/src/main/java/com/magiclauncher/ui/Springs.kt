package com.magiclauncher.ui

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.SpringSpec
import androidx.compose.animation.core.spring

/** Central spring specs. page() is the spec'd LowBouncy + StiffnessLow used for swipes, drops, folders, dock. */
object Springs {
    fun <T> page(): SpringSpec<T> = spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessLow)
    fun <T> shift(): SpringSpec<T> = spring(dampingRatio = 0.82f, stiffness = Spring.StiffnessMedium)
    fun <T> pop(): SpringSpec<T> = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium)
}
