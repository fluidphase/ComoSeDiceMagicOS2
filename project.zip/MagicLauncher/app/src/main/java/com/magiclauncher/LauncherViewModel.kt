package com.magiclauncher

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.magiclauncher.data.*
import com.magiclauncher.engine.GridEngine
import com.magiclauncher.model.*
import com.magiclauncher.ui.ShortcutEntry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.roundToInt

@OptIn(FlowPreview::class)
class LauncherViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Context = app
    val settingsRepo = SettingsRepository(app)
    val settings: StateFlow<LauncherSettings> = settingsRepo.flow
    private val appRepo = AppRepository(app)
    val apps: StateFlow<List<AppInfo>> = appRepo.apps
    val icons = IconRepository(app)
    val recentsRepo = RecentsRepository(app)
    private val layoutRepo = LayoutRepository(app)
    private val launcherApps: LauncherApps = app.getSystemService(LauncherApps::class.java)

    private val _items = MutableStateFlow<List<HomeItem>>(emptyList())
    val items: StateFlow<List<HomeItem>> = _items.asStateFlow()
    private val _dock = MutableStateFlow<List<String>>(emptyList())
    val dock: StateFlow<List<String>> = _dock.asStateFlow()
    private val _recents = MutableStateFlow<List<String>>(emptyList())
    val recents: StateFlow<List<String>> = _recents.asStateFlow()

    val preview = MutableStateFlow<List<HomeItem>?>(null)
    val drag = MutableStateFlow<DragState?>(null)
    val iconVersion = MutableStateFlow(0)
    val wallpaperVersion = MutableStateFlow(0)

    // ephemeral UI state
    var editMode by mutableStateOf(false)
    var openFolderId by mutableStateOf<String?>(null)
    var menuTarget by mutableStateOf<String?>(null)
    var showDrawer by mutableStateOf(false)
    var drawerFocusSearch by mutableStateOf(false)
    var showSettings by mutableStateOf(false)
    var showWidgetPicker by mutableStateOf(false)
    var selectedId by mutableStateOf<String?>(null)
    var launchAnim by mutableStateOf<LaunchAnim?>(null)
    var homeEvent by mutableIntStateOf(0)
    val anyOverlay: Boolean get() = showDrawer || openFolderId != null || showSettings || showWidgetPicker

    var widgetDeleter: ((Int) -> Unit)? = null
    var currentPage = 0
        private set
    private var cellW = 1f
    private var cellH = 1f
    @Volatile private var loaded = false

    init {
        appRepo.register()
        viewModelScope.launch(Dispatchers.Default) {
            appRepo.refresh()
            val s = settings.value
            val saved = layoutRepo.load()
            if (saved != null) {
                _items.value = GridEngine.place(saved.first, null, s.gridCols, s.gridRows)
                _dock.value = saved.second
            } else {
                val (i, d) = buildDefaults(appRepo.apps.value, s)
                _items.value = i; _dock.value = d
            }
            loaded = true
            refreshRecentsInternal()
        }
        viewModelScope.launch {
            settings.map { it.gridCols to it.gridRows }.distinctUntilChanged().collect { (c, r) ->
                if (loaded) _items.update { GridEngine.place(it, null, c, r) }
            }
        }
        viewModelScope.launch {
            settings.map { it.iconPack }.distinctUntilChanged().collect { icons.setPack(it); iconVersion.update { v -> v + 1 } }
        }
        viewModelScope.launch {
            combine(_items, _dock) { a, b -> a to b }.debounce(400).collect {
                if (loaded) withContext(Dispatchers.IO) { layoutRepo.save(it.first, it.second) }
            }
        }
        viewModelScope.launch {
            apps.collect { list -> if (loaded && list.isNotEmpty()) cleanup(list.map { it.key }.toSet()) }
        }
        viewModelScope.launch { _dock.collect { if (loaded) refreshRecentsInternal() } }
    }

    override fun onCleared() { appRepo.unregister() }

    // ---------- defaults ----------
    private fun newId() = UUID.randomUUID().toString()

    private fun buildDefaults(apps: List<AppInfo>, s: LauncherSettings): Pair<List<HomeItem>, List<String>> {
        val pm = ctx.packageManager
        val intents = listOf(
            Intent(Intent.ACTION_DIAL), Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")),
            Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_GALLERY),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_EMAIL),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MAPS),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALENDAR),
            Intent(Settings.ACTION_SETTINGS)
        )
        val defaults = intents.mapNotNull {
            pm.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
        }.distinct().mapNotNull { pkg -> apps.firstOrNull { it.packageName == pkg } }
        val dockApps = defaults.take(5)
        var list = emptyList<HomeItem>()
        fun add(sx: Int, sy: Int, build: (Int, Int, Int) -> HomeItem) {
            val (p, c, r) = GridEngine.firstFree(list, 0, sx, sy, s.gridCols, s.gridRows)
            list = list + build(p, c, r)
        }
        MagicWidgetType.entries.forEach { t ->
            add(t.spanX, t.spanY) { p, c, r ->
                HomeItem(newId(), ItemKind.WIDGET, p, c, r, t.spanX, t.spanY, widgets = listOf(WidgetRef(magic = t)))
            }
        }
        val rest = (defaults - dockApps.toSet()) + apps.filter { it !in defaults }
        rest.take(18).forEach { a -> add(1, 1) { p, c, r -> HomeItem(newId(), ItemKind.APP, p, c, r, key = a.key) } }
        return list to dockApps.map { it.key }
    }

    private fun cleanup(valid: Set<String>) {
        _items.update { l ->
            l.mapNotNull { i ->
                when (i.kind) {
                    ItemKind.APP -> if (i.key in valid) i else null
                    ItemKind.FOLDER -> { val ch = i.children.filter { it in valid }; if (ch.isEmpty()) null else i.copy(children = ch) }
                    ItemKind.WIDGET -> i
                }
            }
        }
        _dock.update { d -> d.filter { it in valid } }
    }

    // ---------- navigation / overlays ----------
    fun goHome() {
        openFolderId = null; showDrawer = false; showSettings = false; showWidgetPicker = false
        menuTarget = null; editMode = false; selectedId = null; homeEvent++
    }

    fun openDrawer(focusSearch: Boolean) { drawerFocusSearch = focusSearch; showDrawer = true }

    fun launch(app: AppInfo, bounds: Rect?, actions: LauncherActions) {
        if (bounds != null && bounds.width > 0f) launchAnim = LaunchAnim(bounds, icons.peek(app.key)?.bitmap)
        actions.launchApp(app, bounds?.takeIf { it.width > 0f })
        recentsRepo.record(app.packageName)
        openFolderId = null; showDrawer = false; menuTarget = null
    }

    // ---------- recents ----------
    fun refreshRecents() { viewModelScope.launch(Dispatchers.Default) { refreshRecentsInternal() } }
    private fun refreshRecentsInternal() {
        val pinnedPk = _dock.value.map { it.substringBefore('/') }.toSet()
        _recents.value = recentsRepo.query(apps.value, pinnedPk, 8)
    }

    // ---------- shortcuts ----------
    suspend fun shortcutsFor(app: AppInfo): List<ShortcutEntry> = withContext(Dispatchers.Default) {
        try {
            val q = LauncherApps.ShortcutQuery()
                .setPackage(app.packageName).setActivity(app.component)
                .setQueryFlags(
                    LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or
                        LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST or
                        LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED
                )
            val dpi = ctx.resources.displayMetrics.densityDpi
            launcherApps.getShortcuts(q, app.user)?.take(4)?.map {
                val bmp: ImageBitmap? = try {
                    launcherApps.getShortcutIconDrawable(it, dpi)?.toBitmap(96, 96)?.asImageBitmap()
                } catch (e: Exception) { null }
                ShortcutEntry(it, bmp)
            } ?: emptyList()
        } catch (e: SecurityException) { emptyList() } catch (e: Exception) { emptyList() }
    }

    // ---------- drag & drop ----------
    fun setGeometry(cw: Float, ch: Float) { cellW = cw; cellH = ch }

    fun startDrag(item: HomeItem) {
        drag.value = DragState(item, Offset(item.col * cellW, item.row * cellH))
        preview.value = null; menuTarget = null
    }

    fun dragBy(delta: Offset) {
        val d = drag.value ?: return
        if (d.dropping) return
        val nd = d.copy(offset = d.offset + delta)
        drag.value = nd
        updatePreview(nd)
    }

    fun onPageChanged(p: Int) {
        currentPage = p
        drag.value?.let { if (!it.dropping) updatePreview(it) }
    }

    private fun canMerge(src: HomeItem, occ: HomeItem): Boolean = when {
        src.kind == ItemKind.APP && (occ.kind == ItemKind.APP || occ.kind == ItemKind.FOLDER) -> true
        src.kind == ItemKind.WIDGET && occ.kind == ItemKind.WIDGET &&
            src.spanX == occ.spanX && src.spanY == occ.spanY -> true
        else -> false
    }

    private fun updatePreview(d: DragState) {
        val s = settings.value
        val src = d.item
        val w = src.spanX * cellW; val h = src.spanY * cellH
        val cx = d.offset.x + w / 2f; val cy = d.offset.y + h / 2f
        val cc = floor(cx / cellW).toInt(); val cr = floor(cy / cellH).toInt()
        val occ = _items.value.firstOrNull { o ->
            o.id != src.id && o.page == currentPage &&
                cc >= o.col && cc < o.col + o.spanX && cr >= o.row && cr < o.row + o.spanY
        }
        var mergeId: String? = null
        if (occ != null && canMerge(src, occ)) {
            val ox = (occ.col + occ.spanX / 2f) * cellW
            val oy = (occ.row + occ.spanY / 2f) * cellH
            if (abs(cx - ox) < occ.spanX * cellW * 0.28f && abs(cy - oy) < occ.spanY * cellH * 0.28f) mergeId = occ.id
        }
        if (mergeId != null) {
            if (preview.value != null) preview.value = null
            if (d.mergeTargetId != mergeId) drag.update { it?.copy(mergeTargetId = mergeId) }
            return
        }
        if (d.mergeTargetId != null) drag.update { it?.copy(mergeTargetId = null) }
        val col = (d.offset.x / cellW).roundToInt().coerceIn(0, max(0, s.gridCols - src.spanX))
        val row = (d.offset.y / cellH).roundToInt().coerceIn(0, max(0, s.gridRows - src.spanY))
        val np = GridEngine.place(_items.value, src.copy(page = currentPage, col = col, row = row), s.gridCols, s.gridRows)
        if (np != preview.value) preview.value = np
    }

    fun endDrag() {
        val d = drag.value ?: return
        if (d.dropping) return
        val s = settings.value
        if (d.offset.y + d.item.spanY * cellH / 2f < 0f) {      // dropped on the remove zone
            removeItem(d.item.id); preview.value = null; drag.value = null; return
        }
        var list = _items.value
        var settle: Offset? = null
        val target = d.mergeTargetId?.let { id -> list.firstOrNull { it.id == id } }
        if (target != null) {
            list = merge(list, d.item, target, s)
            settle = Offset(target.col * cellW, target.row * cellH)
        } else {
            preview.value?.let { list = it }
            val fin = list.firstOrNull { it.id == d.item.id }
            if (fin != null && fin.page == currentPage) settle = Offset(fin.col * cellW, fin.row * cellH)
        }
        _items.value = GridEngine.compactPages(list)
        preview.value = null
        drag.value = d.copy(dropping = true, settleTo = settle)
    }

    fun clearDrag() { drag.value = null }

    private fun merge(list: List<HomeItem>, src: HomeItem, target: HomeItem, s: LauncherSettings): List<HomeItem> {
        val rest = list.filter { it.id != src.id && it.id != target.id }
        return when {
            src.kind == ItemKind.APP && target.kind == ItemKind.APP -> {
                val st = s.defaultFolderStyle
                val folder = HomeItem(
                    newId(), ItemKind.FOLDER, target.page, target.col, target.row, st.spanX, st.spanY,
                    children = listOf(target.key!!, src.key!!), title = "Folder", folderStyle = st
                )
                GridEngine.place(rest, folder, s.gridCols, s.gridRows)
            }
            src.kind == ItemKind.APP && target.kind == ItemKind.FOLDER ->
                rest + target.copy(children = (target.children + src.key!!).distinct())
            src.kind == ItemKind.WIDGET && target.kind == ItemKind.WIDGET ->
                rest + target.copy(widgets = target.widgets + src.widgets)
            else -> list
        }
    }

    // ---------- item operations ----------
    private fun find(id: String) = _items.value.firstOrNull { it.id == id }

    fun removeItem(id: String) {
        val item = find(id) ?: return
        item.widgets.forEach { w -> if (w.appWidgetId >= 0) widgetDeleter?.invoke(w.appWidgetId) }
        _items.update { l -> GridEngine.compactPages(l.filter { x -> x.id != id }) }
        selectedId = null; menuTarget = null
    }

    fun makeFolder(id: String, style: FolderStyle = FolderStyle.BIG) {
        val a = find(id) ?: return
        if (a.kind != ItemKind.APP) return
        val f = a.copy(kind = ItemKind.FOLDER, key = null, children = listOf(a.key!!), title = "Folder",
            folderStyle = style, spanX = style.spanX, spanY = style.spanY)
        val s = settings.value
        _items.value = GridEngine.place(_items.value, f, s.gridCols, s.gridRows)
    }

    fun setFolderStyle(id: String, style: FolderStyle) {
        val f = find(id) ?: return
        val s = settings.value
        _items.value = GridEngine.place(_items.value, f.copy(folderStyle = style, spanX = style.spanX, spanY = style.spanY), s.gridCols, s.gridRows)
    }

    fun dissolveFolder(id: String) {
        val f = find(id) ?: return
        var list = _items.value.filter { it.id != id }
        val s = settings.value
        f.children.forEach { k ->
            val (p, c, r) = GridEngine.firstFree(list, f.page, 1, 1, s.gridCols, s.gridRows)
            list = list + HomeItem(newId(), ItemKind.APP, p, c, r, key = k)
        }
        _items.value = GridEngine.compactPages(list)
    }

    fun removeFromFolder(folderId: String, key: String) {
        val f = find(folderId) ?: return
        val s = settings.value
        val remaining = f.children - key
        var list = _items.value.filter { it.id != folderId }
        if (remaining.isNotEmpty()) list = list + f.copy(children = remaining)
        val (p, c, r) = GridEngine.firstFree(list, f.page, 1, 1, s.gridCols, s.gridRows)
        list = list + HomeItem(newId(), ItemKind.APP, p, c, r, key = key)
        _items.value = GridEngine.compactPages(list)
        if (remaining.isEmpty()) openFolderId = null
    }

    fun addAppToHome(key: String) {
        val s = settings.value
        val (p, c, r) = GridEngine.firstFree(_items.value, currentPage, 1, 1, s.gridCols, s.gridRows)
        _items.update { it + HomeItem(newId(), ItemKind.APP, p, c, r, key = key) }
    }

    fun pinToDock(key: String) { _dock.update { if (key in it || it.size >= 8) it else it + key } }
    fun unpinFromDock(key: String) { _dock.update { it - key } }
    fun moveDock(key: String, delta: Int) {
        _dock.update { d ->
            val i = d.indexOf(key); val j = i + delta
            if (i < 0 || j !in d.indices) d else d.toMutableList().also { it.removeAt(i); it.add(j, key) }
        }
    }

    fun resizeItem(id: String, sx: Int, sy: Int) {
        val it0 = find(id) ?: return
        val s = settings.value
        _items.value = GridEngine.place(_items.value, it0.copy(spanX = sx, spanY = sy), s.gridCols, s.gridRows)
    }

    fun addMagic(t: MagicWidgetType) {
        val s = settings.value
        val (p, c, r) = GridEngine.firstFree(_items.value, currentPage, t.spanX, t.spanY, s.gridCols, s.gridRows)
        _items.update { it + HomeItem(newId(), ItemKind.WIDGET, p, c, r, t.spanX, t.spanY, widgets = listOf(WidgetRef(magic = t))) }
    }

    fun addAppWidget(appWidgetId: Int, sx: Int, sy: Int) {
        val s = settings.value
        val (p, c, r) = GridEngine.firstFree(_items.value, currentPage, sx, sy, s.gridCols, s.gridRows)
        _items.update { it + HomeItem(newId(), ItemKind.WIDGET, p, c, r, sx, sy, widgets = listOf(WidgetRef(appWidgetId))) }
    }

    fun unstack(id: String) {
        val st = find(id) ?: return
        if (st.widgets.size < 2) return
        val s = settings.value
        var list = _items.value.filter { it.id != id }
        st.widgets.forEachIndexed { idx, w ->
            if (idx == 0) list = list + st.copy(widgets = listOf(w))
            else {
                val (p, c, r) = GridEngine.firstFree(list, st.page, st.spanX, st.spanY, s.gridCols, s.gridRows)
                list = list + HomeItem(newId(), ItemKind.WIDGET, p, c, r, st.spanX, st.spanY, widgets = listOf(w))
            }
        }
        _items.value = GridEngine.compactPages(list)
    }

    fun updateSettings(t: (LauncherSettings) -> LauncherSettings) = settingsRepo.update(t)
}
