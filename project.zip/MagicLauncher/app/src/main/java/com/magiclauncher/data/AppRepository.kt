package com.magiclauncher.data

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.os.UserHandle
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.magiclauncher.model.AppInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory

class AppRepository(private val ctx: Context) {
    private val launcherApps: LauncherApps = ctx.getSystemService(LauncherApps::class.java)
    private val _apps = MutableStateFlow<List<AppInfo>>(emptyList())
    val apps: StateFlow<List<AppInfo>> = _apps.asStateFlow()

    fun refresh() {
        val list = launcherApps.profiles.flatMap { user ->
            launcherApps.getActivityList(null, user).map { info ->
                val cn = info.componentName
                AppInfo("${cn.packageName}/${cn.className}", cn.packageName, cn.className, info.label.toString(), user)
            }
        }.filter { it.packageName != ctx.packageName }.sortedBy { it.label.lowercase() }
        _apps.value = list
    }

    private val callback = object : LauncherApps.Callback() {
        override fun onPackageRemoved(packageName: String?, user: UserHandle?) = refresh()
        override fun onPackageAdded(packageName: String?, user: UserHandle?) = refresh()
        override fun onPackageChanged(packageName: String?, user: UserHandle?) = refresh()
        override fun onPackagesAvailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) = refresh()
        override fun onPackagesUnavailable(packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean) = refresh()
    }

    fun register() = launcherApps.registerCallback(callback)
    fun unregister() = launcherApps.unregisterCallback(callback)
}

data class LoadedIcon(val bitmap: ImageBitmap, val masked: Boolean)
data class IconPackInfo(val pkg: String, val label: String)

/**
 * Loads icons off the main thread. Adaptive icons are rendered layer-by-layer (background + foreground,
 * cropped to the 72/108 visible window) so any user-selected shape mask can be applied in Compose.
 */
class IconRepository(private val ctx: Context) {
    private val pm = ctx.packageManager
    private val cache = LruCache<String, LoadedIcon>(400)
    @Volatile private var pack: IconPack? = null

    fun peek(key: String): LoadedIcon? = cache.get(key)

    suspend fun setPack(pkg: String?) = withContext(Dispatchers.Default) {
        pack = pkg?.let { runCatching { IconPack(ctx, it) }.getOrNull() }
        cache.evictAll()
    }

    suspend fun load(key: String): LoadedIcon? {
        cache.get(key)?.let { return it }
        return withContext(Dispatchers.Default) {
            val cn = ComponentName.unflattenFromString(key) ?: return@withContext null
            val packed = pack?.drawableFor(key)
            val result = try {
                if (packed != null) LoadedIcon(render(packed, true), false)
                else LoadedIcon(render(pm.getActivityIcon(cn), false), true)
            } catch (e: Exception) { null }
            if (result != null) cache.put(key, result)
            result
        }
    }

    private fun render(d: Drawable, raw: Boolean): ImageBitmap {
        val size = 192
        if (d is AdaptiveIconDrawable && !raw) {
            val full = (size * 108f / 72f).toInt()
            val big = Bitmap.createBitmap(full, full, Bitmap.Config.ARGB_8888)
            val c = Canvas(big)
            d.background?.let { it.setBounds(0, 0, full, full); it.draw(c) }
            d.foreground?.let { it.setBounds(0, 0, full, full); it.draw(c) }
            val off = (full - size) / 2
            return Bitmap.createBitmap(big, off, off, size, size).asImageBitmap()
        }
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        if (raw) {
            d.setBounds(0, 0, size, size); d.draw(c)
        } else {
            c.drawColor(0xFFF1F1F4.toInt())
            val inset = (size * 0.16f).toInt()
            d.setBounds(inset, inset, size - inset, size - inset); d.draw(c)
        }
        return bmp.asImageBitmap()
    }

    companion object {
        fun availablePacks(ctx: Context): List<IconPackInfo> {
            val pm = ctx.packageManager
            val actions = listOf("org.adw.launcher.THEMES", "com.novalauncher.THEME", "com.gau.go.launcherex.theme")
            return actions.flatMap { pm.queryIntentActivities(Intent(it), 0) }
                .map { it.activityInfo.packageName }.distinct()
                .mapNotNull { pkg ->
                    runCatching { IconPackInfo(pkg, pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()) }.getOrNull()
                }
        }
    }
}

/** Minimal ADW/Nova-style icon pack reader (appfilter.xml: component -> drawable). */
class IconPack(ctx: Context, private val pkg: String) {
    private val res = ctx.packageManager.getResourcesForApplication(pkg)
    private val map = HashMap<String, String>()

    init {
        try {
            val id = res.getIdentifier("appfilter", "xml", pkg)
            val parser: XmlPullParser = if (id != 0) res.getXml(id) else {
                XmlPullParserFactory.newInstance().newPullParser().apply {
                    setInput(res.assets.open("appfilter.xml"), "utf-8")
                }
            }
            var e = parser.eventType
            while (e != XmlPullParser.END_DOCUMENT) {
                if (e == XmlPullParser.START_TAG && parser.name == "item") {
                    val comp = parser.getAttributeValue(null, "component")
                    val dr = parser.getAttributeValue(null, "drawable")
                    if (comp != null && dr != null && comp.contains("{")) {
                        map[comp.substringAfter("{").substringBefore("}")] = dr
                    }
                }
                e = parser.next()
            }
        } catch (_: Exception) { /* empty pack */ }
    }

    fun drawableFor(key: String): Drawable? {
        val name = map[key] ?: return null
        val rid = res.getIdentifier(name, "drawable", pkg)
        if (rid == 0) return null
        return try { res.getDrawable(rid, null) } catch (e: Exception) { null }
    }
}
