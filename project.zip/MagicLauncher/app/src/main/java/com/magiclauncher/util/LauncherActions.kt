package com.magiclauncher

import android.content.Intent
import android.content.pm.ShortcutInfo
import androidx.compose.ui.geometry.Rect
import com.magiclauncher.model.AppInfo

/** Everything the UI needs from the Activity (starting activities, system panels, permissions). */
interface LauncherActions {
    fun launchApp(app: AppInfo, bounds: Rect?, newWindow: Boolean = false)
    fun startShortcut(s: ShortcutInfo)
    fun appInfo(app: AppInfo)
    fun uninstall(app: AppInfo)
    fun expandNotifications()
    fun expandQuickSettings()
    fun lockScreen()
    fun openUsageAccessSettings()
    fun openAccessibilitySettings()
    fun requestWallpaperPermission()
    fun webSearch(query: String)
    fun openSystem(intent: Intent)
    fun isUsageAccessGranted(): Boolean
    fun isAccessibilityEnabled(): Boolean
}
