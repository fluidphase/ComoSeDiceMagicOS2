# Magic Launcher (tablet-first MagicOS-style launcher)

Kotlin + Jetpack Compose, minSdk 29 (Android 10), targetSdk 35.

## Build
Push `project.zip` + `.github/workflows/build.yml` to GitHub; the workflow extracts the zip and builds
`app-debug.apk` (see the run's Artifacts). Locally: unzip, open in Android Studio, or `gradle assembleDebug`.
Set it as default Home app after install.

## Layout
| File | What |
|---|---|
| `ui/HomeScreen.kt` | pager desktop, drag-and-drop, edit mode, overlays |
| `ui/BigFolder.kt` | 1×1 / 2×2 (3×3 icons, +N overflow) / 2×1 (4×2) folders, direct-tap launch, blurred overlay |
| `ui/DynamicDock.kt` | pinned | divider | recents, spring-animated width, glass backdrop |
| `ui/WallpaperLayer.kt` | parallax wallpaper, RenderEffect blur (API 31+), pure-Kotlin box blur (API 29/30) |
| `ui/AppIcon.kt`, `ui/IconShapes.kt` | masked icons (circle/squircle/teardrop/rounded), icon packs |
| `ui/GestureContainer.kt` | swipe down/up, pinch-in, double-tap, per-item tap/drag |
| `ui/ContextMenu.kt` | long-press menu: LauncherApps shortcuts, app info, uninstall, folder styles |
| `ui/Widgets.kt` | AppWidgetHostView hosting, Clock/Weather/Battery/Storage cards, stacks, magnetic resize, picker |
| `ui/LaunchTransition.kt` | icon-bounds → fullscreen zoom and collapse on return home |
| `engine/GridEngine.kt` | collision displacement, free-slot search |
| `LauncherViewModel.kt` | StateFlow state, drag preview/merge/drop logic, persistence |

## Permissions to grant in-app (Settings → Permissions)
* Usage access → recent apps in dock
* Accessibility service → notification panel / control center / lock-screen gestures
* Wallpaper access (Android ≤ 12) → real wallpaper for parallax + dock blur

## Known limits
* Not compiled in the authoring environment; expect to fix small compile errors on first build.
* Dock icons can be pinned/unpinned via menu (no drag from desktop to dock yet).
* Android 13+ may deny wallpaper bitmap access to non-system apps; a gradient is shown then.
* App shortcuts require being the default Home app.
